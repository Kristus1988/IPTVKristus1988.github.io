# -*- coding: utf-8 -*-

# 2022-10-09
# edit 2025-03-29

import sys, os
from xbmcaddon import Addon
from resources.lib.requestHandler import cRequestHandler

is_python2 = sys.version_info.major == 2
if is_python2:
	from xbmc import translatePath
	from urlparse import urlparse
else:
	from xbmcvfs import translatePath
	from urllib.parse import urlparse

addonInfo = Addon().getAddonInfo
addonPath = translatePath(addonInfo('path'))
addonVersion = addonInfo('version')
setSetting = Addon().setSetting
_getSetting = Addon().getSetting

def getSetting(Name, default=''):
	result = _getSetting(Name)
	if result: return result
	else: return default

# Html Cache beim KodiStart loeschen
def delHtmlCache():
	from time import time
	deltaDay = int(getSetting('cacheDeltaDay', 2))
	deltaTime = 60*60*24*deltaDay # Tage
	currentTime = int(time())
	# einmalig
	if getSetting('delHtmlCache') == 'true':
		cRequestHandler('').clearCache()
		setSetting('lastdelhtml', str(currentTime))
		setSetting('delHtmlCache', 'false')
	# alle x Tage
	elif currentTime >= int(getSetting('lastdelhtml', 0)) + deltaTime:
		cRequestHandler('').clearCache()
		setSetting('lastdelhtml', str(currentTime))

# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]	 providername identisch mit dateiname
def _getPluginData():
	from os import path, listdir
	sPluginFolder = path.join(addonPath, 'scrapers', 'scrapers_source', 'de')
	sys.path.append(sPluginFolder)
	items = listdir(sPluginFolder)
	aFileNames=[]
	aPluginsData = []
	for sItemName in items:
		if sItemName.endswith('.py'): aFileNames.append(sItemName[:-3])
	for fileName in aFileNames:
		if fileName ==  '__init__': continue
		try:
			plugin = __import__(fileName, globals(), locals())
			# print(plugin.SITE_DOMAIN +'  '+ plugin.SITE_IDENTIFIER)
			aPluginsData.append({'domain': plugin.SITE_DOMAIN, 'provider': plugin.SITE_IDENTIFIER})
		except:
			pass
	return aPluginsData

def check_domains():
	import requests
	requests.packages.urllib3.disable_warnings()	# weil verify = False - ansonst Fehlermeldungen im kodi log
	domains = _getPluginData()
	for item in domains:
		_domain = item['domain']
		_provider = item['provider']
		if _provider == 'vavoo':
			setSetting('provider.' + _provider + '.check', 'true')
			continue
		domain = getSetting('provider.'+ _provider +'.domain', _domain)
		base_link = 'https://' + domain
		try:
			r = requests.head(base_link, verify = False)
			status_code = r.status_code
			if 300 <= status_code <= 400:
				url = r.headers['Location']
				#setSetting('provider.'+ _provider +'.base_link', url)
				setSetting('provider.' + _provider + '.domain', urlparse(url).hostname)
				setSetting('provider.' + _provider + '.check', 'true')
			elif status_code == 200:
				#setSetting('provider.' + provider + '.base_link', base_link)
				setSetting('provider.' + _provider + '.domain', urlparse(base_link).hostname)
				setSetting('provider.' + _provider + '.check', 'true')
			# elif status_code == 403:
			#	 #setSetting('provider.' + provider + '.base_link', base_link)
			#	 setSetting('provider.' + _provider + '.domain', urlparse(base_link).hostname)
			#	 setSetting('provider.' + _provider + '.check', 'true')
			else:
				setSetting('provider.' + _provider + '.check', 'false')
				setSetting('provider.' + _provider + '.domain', domain)
		except:
			setSetting('provider.' + _provider + '.check', 'false')
			setSetting('provider.' + _provider + '.domain', domain)
			pass

def main():
	import xbmc
	if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
		xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
		xbmc.executebuiltin('SendClick(11)')
	#check_domains()
	delHtmlCache()


if __name__ == "__main__":
	main()